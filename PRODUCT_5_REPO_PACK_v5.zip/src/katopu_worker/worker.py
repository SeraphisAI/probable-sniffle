from __future__ import annotations

import os
import sys
from typing import Any, Callable, Dict

from rq import Connection, Queue, Worker
from redis import Redis

from katopu_worker import tasks


def _redis_url() -> str:
    return os.environ.get("KATOPU_REDIS_URL", "redis://redis:6379/0")


def _queues() -> list[str]:
    q = os.environ.get("KATOPU_WORKER_QUEUES", "default").strip()
    return [x.strip() for x in q.split(",") if x.strip()] or ["default"]


def _register_jobs() -> Dict[str, Callable[..., Any]]:
    # Explicit registry to keep imports safe/controlled.
    return {
        "compact_runs": tasks.compact_runs_jsonl,
        "purge_deleted": tasks.purge_deleted_runs_jsonl,
        "healthcheck": tasks.healthcheck_task,
    }


def main() -> None:
    redis = Redis.from_url(_redis_url())
    queues = _queues()
    job_registry = _register_jobs()

    for name, fn in job_registry.items():
        if not callable(fn):
            raise RuntimeError(f"job {name} not callable")

    with Connection(redis):
        qs = [Queue(q) for q in queues]
        w = Worker(qs)
        w.work(with_scheduler=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
