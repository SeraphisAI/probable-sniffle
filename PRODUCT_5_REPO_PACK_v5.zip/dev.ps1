param(
  [Parameter(Position=0)]
  [ValidateSet("up","down","restart","status","logs","build","up-worker","down-worker","ps","help")]
  [string]$cmd="help",

  [Parameter(Position=1)]
  [string]$service=""
)

$ErrorActionPreference = "Stop"

function RepoRoot {
  $here = Split-Path -Parent $MyInvocation.MyCommand.Path
  return $here
}

function InfraDir {
  return (Join-Path (RepoRoot) "infra")
}

function DC {
  param([string[]]$args)
  $infra = InfraDir
  Push-Location $infra
  try {
    docker compose @args
  } finally {
    Pop-Location
  }
}

switch ($cmd) {
  "up" {
    DC @("up","-d","--build")
    DC @("ps")
  }
  "up-worker" {
    DC @("--profile","worker","up","-d","--build")
    DC @("--profile","worker","ps")
  }
  "build" { DC @("build") }
  "down" { DC @("down","--remove-orphans") }
  "down-worker" { DC @("--profile","worker","down","--remove-orphans") }
  "restart" {
    if ($service -and $service.Trim().Length -gt 0) {
      DC @("up","-d","--no-deps","--force-recreate",$service)
    } else {
      DC @("up","-d","--force-recreate")
    }
    DC @("ps")
  }
  "status" { DC @("ps") }
  "ps" { DC @("ps") }
  "logs" {
    if ($service -and $service.Trim().Length -gt 0) {
      DC @("logs","-f",$service)
    } else {
      DC @("logs","-f")
    }
  }
  default {
    Write-Host ""
    Write-Host "Katopu GenLab Ultra — single-command runner"
    Write-Host ""
    Write-Host "Usage:"
    Write-Host "  .\dev.ps1 up                 # api + ui"
    Write-Host "  .\dev.ps1 up-worker          # api + ui + redis + worker"
    Write-Host "  .\dev.ps1 logs ui            # follow logs"
    Write-Host "  .\dev.ps1 restart ui         # recreate one service"
    Write-Host "  .\dev.ps1 down               # stop"
    Write-Host ""
  }
}
