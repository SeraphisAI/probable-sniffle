# DELIVERY_REPORT — Katopu GenLab Ultra UI (v0.3.0)

## Özet
Bu teslimat, UI’nin “butonlar çalışmıyor / analiz yok / sayfa kayıyor” problemlerini giderip **ürün seviyesi** bir yerleşim ve **parite** geri kazanımı sağlar.

## Başlıca Düzeltmeler
- UI ile README arasındaki “fallback + policy panel” parite bozukluğu giderildi.
- API `/run` endpoint kontratı düzeltildi: sequence query param olarak gönderiliyor.
- Engine “Auto”: API sağlıklıysa API, değilse Local fallback.
- Global CSS ile taşma/wrap problemleri bastırıldı (nowrap/ellipsis, hyphens:none, overflow-x:hidden).

## Parity (Geri Gelen Özellikler)
- Multi‑Gene Editor (FASTA import/export, multi‑paste, duplike, meta, chunk view)
- Workspace DNA/RNA input alanı (IUPAC doğrulama + hata pozisyonu)
- Son 20 rapor listesi (Aç / Pin / Compare / Export)
- Compare Runs (A/B before/after + inline diff + side-by-side diff)

## Yeni / İyileştirilen Özellikler
- Pro topbar (sticky) + durum rozetleri (API/Policy/Telemetry)
- Toolbar: Run/Spec/Apply/Validate/Compare/Export/Save/Clear/Settings/Diagnostics
- Export bundle: JSON + XLSX + PDF tek zip

## Kalite Kapıları (Bu ortamda koşturulan)
- `python -m compileall` (syntax/smoke)
- `pytest -q` (unit testler)

> Not: Streamlit/Playwright gibi UI e2e testleri bu teslimatta “opsiyonel” olarak dokümante edildi; unit testler Streamlit’e bağımlı olmadan çalışır.

## Nasıl Çalıştırılır?
- Docker: `cd infra && docker compose up -d --build`
- UI: http://localhost:8501

## Bilinen Sınırlar / Riskler
- Streamlit DOM kısıtları nedeniyle gerçek “sağ sidebar” yerine inspector HTML paneli kullanılır.
- Pinned state “meta” kaydı olarak JSONL’e eklenir (basit merge yapılır).
