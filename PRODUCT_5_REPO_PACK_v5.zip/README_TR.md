# Katopu GenLab (Ultra) — Kurulum (Windows)

Bu paket **tek klasör** olarak çalışır.

## 1) ZIP’i aç
Önerilen hedef:
- `C:\katopu_genlab_ultra_final`

## 2) Scriptleri “Unblock” et
PowerShell:

```powershell
Get-ChildItem -Recurse -Filter *.ps1 | Unblock-File
```

## 3) Kur (tek komut)
**Admin PowerShell** açıp şunu çalıştır:

```powershell
.\katopu_install.ps1 -NukeDockerData
```

> Not: `-NukeDockerData` compose volume’ları temizler (bu proje verilerini sıfırlar).

## Doğrulama

```powershell
.\katopu_verify.ps1
```

## Kaldır (temiz)

```powershell
.\katopu_uninstall_clean.ps1
```

## URL’ler
- UI: `http://localhost:8501`
- API: `http://localhost:8000`
- Docs: `http://localhost:8000/docs`
