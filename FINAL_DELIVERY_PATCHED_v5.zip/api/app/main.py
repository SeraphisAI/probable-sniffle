from __future__ import annotations

import os
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

from fastapi import Body, FastAPI, Query, Request
from fastapi.responses import JSONResponse

from api.app.config import settings
from katopu_core.omega_engine import apply_editspec, nl_to_editspec, run_intent
from katopu_policy.audit import PolicyAudit
from katopu_policy.evaluator import PolicyEvaluator
from katopu_telemetry.emitter import TelemetryEmitter
from katopu_privacy.mask import mask_dict
from katopu_shared.contract_utils import (
    ERR_MISSING_PARAM,
    ERR_POLICY_BLOCK,
    ERR_RATE_LIMITED,
    ERR_SERVER_ERROR,
    ERR_VALIDATION_ERROR,
    make_editspec,
    make_error,
    make_error_result,
    sha256_hex,
)
from katopu_shared.ids import CONTRACT_VERSION, ENGINE_VERSION


# -----------------------------
# Rate limiting (token bucket)
# -----------------------------
@dataclass
class RateLimitDecision:
    allowed: bool
    retry_after_s: float


class TokenBucket:
    def __init__(self, rate_rps: float, burst: int):
        self.rate_rps = max(0.0, float(rate_rps))
        self.burst = max(1, int(burst))
        self._tokens: Dict[str, float] = {}
        self._last: Dict[str, float] = {}

    def consume(self, key: str, now: Optional[float] = None) -> RateLimitDecision:
        if self.rate_rps <= 0:
            return RateLimitDecision(True, 0.0)
        now = time.time() if now is None else now
        last = self._last.get(key, now)
        tokens = self._tokens.get(key, float(self.burst))

        # refill
        tokens = min(float(self.burst), tokens + (now - last) * self.rate_rps)
        self._last[key] = now

        if tokens >= 1.0:
            tokens -= 1.0
            self._tokens[key] = tokens
            return RateLimitDecision(True, 0.0)

        # retry after enough time for 1 token
        deficit = 1.0 - tokens
        retry_after_s = max(0.0, deficit / self.rate_rps)
        self._tokens[key] = tokens
        return RateLimitDecision(False, retry_after_s)


def _client_key(req: Request) -> str:
    # Prefer X-Forwarded-For if present
    xff = req.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip() or "unknown"
    if req.client and req.client.host:
        return req.client.host
    return "unknown"


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


REQUIRE_API_KEY = _bool_env("KATOPU_REQUIRE_API_KEY", False)
API_KEY = settings.api_key
LIMITER = TokenBucket(rate_rps=settings.rate_rps, burst=settings.rate_burst)

APP_STARTED_AT = time.time()


# -----------------------------
# Policy provider (handles override switching + reload)
# -----------------------------
_policy_cache: Dict[str, Any] = {"path": None, "mtime": None, "evaluator": None}


def _resolve_policy_paths() -> Tuple[str, str, str, bool]:
    # Prefer override if it exists; fall back to base policy path.
    base_path = settings.policy_path
    override_path = settings.policy_override_path
    override_present = bool(override_path) and os.path.exists(override_path)
    active_path = override_path if override_present else base_path
    return active_path, base_path, override_path, override_present


def get_policy() -> Tuple[PolicyEvaluator, Dict[str, Any]]:
    active_path, base_path, override_path, override_present = _resolve_policy_paths()

    try:
        mtime = os.path.getmtime(active_path)
    except OSError:
        mtime = None

    cached_path = _policy_cache.get("path")
    pe: Optional[PolicyEvaluator] = _policy_cache.get("evaluator")

    if pe is None or cached_path != active_path:
        pe = PolicyEvaluator(path=active_path)
        _policy_cache.update({"path": active_path, "mtime": mtime, "evaluator": pe})
    else:
        # Same path; PolicyEvaluator.reload() is safe & cheap.
        pe.reload()
        _policy_cache["mtime"] = mtime

    info = {
        "schema": "katopu.policy.info.v1",
        "path": active_path,
        "override": override_present,
        "base_path": base_path,
        "override_path": override_path,
        "active_path": active_path,
        "override_present": override_present,
        "mtime": mtime,
        "rules": pe.rules(),
        "_meta": {"contract": CONTRACT_VERSION, "engine": ENGINE_VERSION},
    }
    return pe, info


# -----------------------------
# Audit + telemetry
# -----------------------------
_audit = PolicyAudit(settings.policy_audit_path)
_emitter = TelemetryEmitter(
    enabled=settings.telemetry_enabled,
    sample_rate=settings.telemetry_sample_rate,
    path=settings.telemetry_path,
)


def _emit(event: Dict[str, Any]) -> None:
    if not settings.telemetry_enabled:
        return
    try:
        _emitter.emit(event)
    except Exception:
        # Never break the request path because telemetry failed.
        return


app = FastAPI(title="Katopu GenLab Ω API", version="1.0.0")
app.state.limiter = LIMITER


@app.middleware("http")
async def request_id_and_rate_limit(request: Request, call_next):
    request.state.request_id = str(uuid.uuid4())

    # auth (simple shared secret)
    if REQUIRE_API_KEY:
        provided = request.headers.get("x-api-key", "")
        if not API_KEY or provided != API_KEY:
            body = make_error_result(
                before="",
                code=ERR_POLICY_BLOCK,
                message="Missing/invalid API key",
                detail={"required": True},
                request_id=request.state.request_id,
            )
            return JSONResponse(status_code=403, content=body)

    # rate limit
    decision = LIMITER.consume(_client_key(request))
    if not decision.allowed:
        retry_after = max(0.001, decision.retry_after_s)
        if request.url.path.rstrip("/") == "/nl/spec":
            spec = make_editspec(
                op="UNPARSED",
                params={},
                intent_norm="",
                strict_mode=True,
                errors=[
                    make_error(
                        code=ERR_RATE_LIMITED,
                        message="Rate limited",
                        detail={"retry_after_ms": int(retry_after * 1000)},
                    )
                ],
            )
            spec["_meta"] = {
                "contract": CONTRACT_VERSION,
                "engine": ENGINE_VERSION,
                "source": "api",
                "request_id": request.state.request_id,
            }
            resp = JSONResponse(status_code=429, content=spec)
        else:
            body = make_error_result(
                before="",
                code=ERR_RATE_LIMITED,
                message="Rate limited",
                detail={"retry_after_ms": int(retry_after * 1000)},
                request_id=request.state.request_id,
            )
            resp = JSONResponse(status_code=429, content=body)
        resp.headers["Retry-After"] = f"{retry_after:.3f}"
        resp.headers["X-Request-ID"] = request.state.request_id
        return resp

    response = await call_next(request)
    response.headers.setdefault("X-Request-ID", request.state.request_id)
    return response


# -----------------------------
# Endpoints
# -----------------------------
@app.get("/health")
def health():
    return {
        "ok": True,
        "uptime_s": int(time.time() - APP_STARTED_AT),
        "_meta": {
            "contract": CONTRACT_VERSION,
            "engine": ENGINE_VERSION,
            "source": "api",
        },
    }


@app.get("/policy")
def policy_info():
    _, info = get_policy()
    return info


@app.post("/nl/spec")
def nl_spec(request: Request, payload: Dict[str, Any] = Body(...)):
    intent = str(payload.get("intent", ""))
    if not intent:
        return make_editspec(
            op="UNPARSED",
            params={},
            intent_norm="",
            strict_mode=True,
            errors=[make_error(code=ERR_MISSING_PARAM, message="intent is required")],
        )
    if len(intent) > settings.max_intent_len:
        return make_editspec(
            op="UNPARSED",
            params={},
            intent_norm="",
            strict_mode=True,
            errors=[
                make_error(
                    code=ERR_VALIDATION_ERROR,
                    message="intent too long",
                    detail={
                        "max_intent_len": settings.max_intent_len,
                        "len": len(intent),
                    },
                )
            ],
        )

    mode = str(payload.get("mode", "strict")).lower().strip() or "strict"
    strict = mode != "lenient"

    spec = nl_to_editspec(intent, strict_mode=strict)
    spec.setdefault("_meta", {})
    spec["_meta"].update(
        {
            "contract": CONTRACT_VERSION,
            "engine": ENGINE_VERSION,
            "source": "api",
            "request_id": getattr(getattr(request, "state", None), "request_id", None),
        }
    )
    return spec


@app.post("/edit/apply")
def edit_apply(request: Request, payload: Dict[str, Any] = Body(...)):
    mode = str(payload.get("mode", "strict")).lower().strip() or "strict"
    strict = mode != "lenient"

    sequence = str(payload.get("sequence", ""))
    if not sequence:
        return make_error_result(
            before="",
            code=ERR_MISSING_PARAM,
            message="sequence is required",
            request_id=getattr(getattr(request, "state", None), "request_id", None),
        )
    if len(sequence) > settings.max_sequence_len:
        return make_error_result(
            before="",
            code=ERR_VALIDATION_ERROR,
            message="sequence too long",
            detail={
                "max_sequence_len": settings.max_sequence_len,
                "len": len(sequence),
            },
            request_id=getattr(getattr(request, "state", None), "request_id", None),
        )

    raw_spec = (
        payload.get("spec") or payload.get("edit_spec") or payload.get("editspec")
    )
    spec = raw_spec if isinstance(raw_spec, dict) else {}

    rid = getattr(getattr(request, "state", None), "request_id", None)
    policy, _ = get_policy()

    result = apply_editspec(
        sequence=sequence, spec=spec, strict_mode=strict, policy=policy, request_id=rid
    )

    # Audit + telemetry (no raw sequences)
    try:
        pol = result.get("_policy") or {}
        _audit.write(
            {
                "request_id": rid,
                "allowed": bool(pol.get("allowed", True)),
                "reason": pol.get("reason", ""),
                "audit_id": pol.get("audit_id", ""),
                "op": (spec.get("op") if isinstance(spec, dict) else None),
                "sequence_len": len(sequence),
                "sequence_sha256": sha256_hex(sequence),
            }
        )
    except Exception:
        pass

    _emit(
        mask_dict(
            {
                "ts": time.time(),
                "event": "edit_apply",
                "request_id": rid,
                "ok": result.get("ok"),
                "effect_label": result.get("effect_label"),
                "errors": result.get("errors"),
                "sequence_len": len(sequence),
                "sequence_sha256": sha256_hex(sequence),
            }
        )
    )

    return result


@app.post("/run")
def run(
    request: Request,
    sequence: str = Query(..., description="DNA/RNA sequence"),
    payload: Dict[str, Any] = Body(...),
):
    mode = str(payload.get("mode", "strict")).lower().strip() or "strict"
    strict = mode != "lenient"
    intent = str(payload.get("intent", ""))

    if not sequence:
        return make_error_result(
            before="", code=ERR_MISSING_PARAM, message="sequence is required"
        )
    if len(sequence) > settings.max_sequence_len:
        return make_error_result(
            before="",
            code=ERR_VALIDATION_ERROR,
            message="sequence too long",
            detail={
                "max_sequence_len": settings.max_sequence_len,
                "len": len(sequence),
            },
        )
    if not intent:
        return make_error_result(
            before="", code=ERR_MISSING_PARAM, message="intent is required"
        )
    if len(intent) > settings.max_intent_len:
        return make_error_result(
            before="",
            code=ERR_VALIDATION_ERROR,
            message="intent too long",
            detail={"max_intent_len": settings.max_intent_len, "len": len(intent)},
        )

    rid = getattr(getattr(request, "state", None), "request_id", None)
    policy, _ = get_policy()

    result = run_intent(
        sequence=sequence,
        intent=intent,
        strict_mode=strict,
        policy=policy,
        request_id=rid,
    )

    _emit(
        mask_dict(
            {
                "ts": time.time(),
                "event": "run",
                "request_id": rid,
                "ok": result.get("ok"),
                "effect_label": result.get("effect_label"),
                "errors": result.get("errors"),
                "sequence_len": len(sequence),
                "sequence_sha256": sha256_hex(sequence),
                "intent_len": len(intent),
                "intent_sha256": sha256_hex(intent),
            }
        )
    )

    return result


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    # Don't leak internal details
    rid = getattr(getattr(request, "state", None), "request_id", None)
    body = make_error_result(
        before="",
        code=ERR_SERVER_ERROR,
        message="Server error",
        detail={"type": type(exc).__name__},
        request_id=rid,
    )
    return JSONResponse(status_code=500, content=body)
