"""
Katopu GenLab — Ultra (Streamlit)

Zorunlu fix'ler:
- NAV/STREAMLIT “PAGE KEY” BUG FIX: deferred navigation (nav_to) + sidebar radio öncesi apply
- BATH/BATCH geri geldi: Reports + Multi-Gene Editor multi-select + Bulk Action Bar
- Meta merge (last meta wins) + pinned sort (pinned first, newest-first)
- /health cache (ttl=10s)
- /run body-first, 404/405 legacy fallback (kısa seq), aksi halde local fallback + net uyarı
- XLSX export cell-limit fix: chunk

Not: Bu dosya Python dosyasıdır. Terminalde PowerShell’e st.session_state satırı yazılmaz.
"""

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
import streamlit as st
import streamlit.components.v1 as components

from katopu_core.omega_engine import apply_editspec, intent_to_editspec, run_intent
from katopu_policy.evaluator import PolicyEvaluator
from katopu_shared.ids import CONTRACT_VERSION

from katopu_ui.diffview import diff_stats, inline_diff_html, side_by_side_diff_html
from katopu_ui.seq import format_chunked, parse_fasta, to_fasta, validate_iupac
from katopu_ui.store import Gene, GeneStore, append_run
from katopu_ui.ui_contract import APP_VERSION, GLOBAL_CSS, topbar_html

from katopu_ui.history import (
    filter_runs,
    load_runs_with_meta,
    now_iso_utc,
    sort_runs_pinned_newest,
)
from katopu_ui.export_utils import (
    make_bundle_zip,
    make_bundle_zip_many,
    make_jsonl_bytes,
    make_pdf_bytes,
    make_xlsx_bytes,
)

# -----------------------------
# Paths / Defaults
# -----------------------------
DEFAULT_API_BASE = os.environ.get("KATOPU_API_BASE", "http://localhost:8000").rstrip("/")
DEFAULT_TIMEOUT_S = float(os.environ.get("KATOPU_HTTP_TIMEOUT_S", "8"))
RUNS_PATH = Path(os.environ.get("KATOPU_UI_RUNS_PATH", "/data/ui_runs.jsonl"))
GENES_PATH = Path(os.environ.get("KATOPU_UI_GENES_PATH", "/data/ui_genes.json"))
POLICY_BASE_PATH = Path(os.environ.get("KATOPU_POLICY_PATH", "/policies/default.policy.json"))
POLICY_OVERRIDE_PATH = Path(os.environ.get("KATOPU_POLICY_OVERRIDE_PATH", "/data/policy_override.json"))

MAX_TABLE_ROWS = 250
HEALTH_TTL_S = 10
LEGACY_QUERY_FALLBACK_MAX_SEQ = 1400  # URL riskini sınırlamak için

# -----------------------------
# NAV helpers (deferred navigation)
# -----------------------------
def nav_to(page_name: str) -> None:
    """
    IMPORTANT:
    - st.radio(..., key="page") instantiate edildikten sonra aynı run içinde st.session_state["page"] set etme.
    - Onun yerine nav_to kullan: ss["nav_to"]=page; st.rerun()
    - Sidebar radio’dan hemen önce nav_to uygulanacak.
    """
    st.session_state["nav_to"] = page_name
    st.rerun()


# -----------------------------
# HTTP helpers
# -----------------------------
def _make_headers(api_key: str) -> Dict[str, str]:
    h = {"Content-Type": "application/json"}
    if api_key:
        h["X-API-Key"] = api_key
        h["Authorization"] = f"Bearer {api_key}"
    return h


def api_get(api_base: str, path: str, *, timeout_s: float, api_key: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    try:
        r = requests.get(api_base + path, headers=_make_headers(api_key), timeout=timeout_s)
        if r.status_code >= 400:
            return None, f"{r.status_code}: {r.text[:300]}"
        return r.json(), None
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"


def api_post_raw(
    api_base: str,
    path: str,
    *,
    timeout_s: float,
    api_key: str,
    body: Dict[str, Any],
) -> Tuple[Optional[Dict[str, Any]], Optional[str], Optional[int]]:
    try:
        r = requests.post(api_base + path, headers=_make_headers(api_key), timeout=timeout_s, json=body)
        if r.status_code >= 400:
            return None, f"{r.status_code}: {r.text[:300]}", r.status_code
        return r.json(), None, r.status_code
    except Exception as e:
        return None, f"{type(e).__name__}: {e}", None


@st.cache_data(ttl=HEALTH_TTL_S, show_spinner=False)
def cached_api_health(api_base: str, timeout_s: float, api_key: str) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
    obj, err = api_get(api_base, "/health", timeout_s=timeout_s, api_key=api_key)
    ok = bool(obj and obj.get("ok") is True)
    return ok, obj, err

@st.cache_data(ttl=5.0)
def cached_api_capabilities(api_base: str, api_key: str | None = None) -> tuple[bool, dict, str | None]:
    try:
        headers = {}
        if api_key:
            headers["x-api-key"] = api_key
        r = requests.get(f"{api_base}/capabilities", headers=headers, timeout=3)
        r.raise_for_status()
        obj = r.json()
        return True, obj, None
    except Exception as e:
        return False, {}, str(e)


def api_run_body_first(
    api_base: str,
    *,
    sequence: str,
    intent: str,
    mode: str,
    timeout_s: float,
    api_key: str,
) -> Tuple[Optional[Dict[str, Any]], Optional[str], str]:
    """
    /run:
    - Önce POST body ile dene: {"sequence","intent","mode"}
    - Backend eskiyse (404/405): legacy query fallback (sequence kısa ise)
    """
    body = {"sequence": sequence, "intent": intent, "mode": mode}
    obj, err, code = api_post_raw(api_base, "/run", timeout_s=timeout_s, api_key=api_key, body=body)
    if obj is not None and not err:
        return obj, None, "body"

    if code in (404, 405):
        if len(sequence) > LEGACY_QUERY_FALLBACK_MAX_SEQ:
            return None, (
                "Backend /run body desteklemiyor (404/405) ve sequence çok uzun olduğu için "
                "legacy query fallback güvenli değil. Engine=Local kullan veya API'yi güncelle."
            ), "legacy_query"

        qseq = requests.utils.quote(sequence, safe="")
        obj2, err2, _ = api_post_raw(
            api_base,
            "/run?sequence=" + qseq,
            timeout_s=timeout_s,
            api_key=api_key,
            body={"intent": intent, "mode": mode},
        )
        return obj2, err2, "legacy_query"

    return None, err, "body"


# -----------------------------
# Shortcuts (optional UX)
# -----------------------------
def _get_query_params() -> Dict[str, Any]:
    try:
        return dict(st.query_params)
    except Exception:
        try:
            return st.experimental_get_query_params()  # type: ignore
        except Exception:
            return {}


def _clear_query_params() -> None:
    try:
        st.query_params.clear()
    except Exception:
        try:
            st.experimental_set_query_params()  # type: ignore
        except Exception:
            pass


def inject_shortcuts_js() -> None:
    js = r"""
    <script>
    (function(){
      const send = (action) => {
        try{
          const url = new URL(window.parent.location.href);
          url.searchParams.set('kat_action', action);
          window.parent.history.replaceState({}, '', url.toString());
          window.parent.dispatchEvent(new PopStateEvent('popstate'));
        }catch(e){}
      };
      window.addEventListener('keydown', function(e){
        const meta = e.metaKey || e.ctrlKey;
        if(!meta) return;
        const k = (e.key || '').toLowerCase();
        if(k === 'k'){ e.preventDefault(); send('palette'); }
        if(k === 'enter'){ e.preventDefault(); send('run'); }
        if(k === 's'){ e.preventDefault(); send('save'); }
        if(k === 'p'){ e.preventDefault(); send('export'); }
      }, true);
    })();
    </script>
    """
    components.html(js, height=0)


def handle_shortcut_actions() -> Dict[str, bool]:
    qp = _get_query_params()
    v = qp.get("kat_action") if isinstance(qp, dict) else None
    action = (v[0] if isinstance(v, list) and v else v) if v else None
    if not action:
        return {"palette": False, "run": False, "save": False, "export": False}
    _clear_query_params()
    return {
        "palette": action == "palette",
        "run": action == "run",
        "save": action == "save",
        "export": action == "export",
    }


# -----------------------------
# State init
# -----------------------------
def ss_init() -> None:
    st.session_state.setdefault("page", "Workspace (Lab)")
    st.session_state.setdefault("nav_to", None)  # REQUIRED

    st.session_state.setdefault("view_mode", "Run Mode")  # Editor Mode | Run Mode | Review Mode
    st.session_state.setdefault("seq_kind", "dna")  # REQUIRED
    st.session_state.setdefault("mode_strict", True)  # REQUIRED

    st.session_state.setdefault("api_base", DEFAULT_API_BASE)
    st.session_state.setdefault("api_key", "")
    st.session_state.setdefault("timeout_s", DEFAULT_TIMEOUT_S)
    st.session_state.setdefault("engine_mode", "Auto")  # Auto | API | Local
    st.session_state.setdefault("enable_local_fallback", True)

    st.session_state.setdefault("save_history", True)
    st.session_state.setdefault("store_full_sequence", True)

    st.session_state.setdefault("selected_gene_id", "")
    st.session_state.setdefault("selected_run_id", "")
    st.session_state.setdefault("current_sequence", "")
    st.session_state.setdefault("current_intent", "")
    st.session_state.setdefault("current_report_name", "")
    st.session_state.setdefault("current_spec", None)
    st.session_state.setdefault("current_result", None)
    st.session_state.setdefault("last_run_full", None)

    st.session_state.setdefault("pipeline_step", "Idle")
    st.session_state.setdefault("show_palette", False)
    st.session_state.setdefault("global_search", "")

    st.session_state.setdefault("trigger_run", False)
    st.session_state.setdefault("trigger_save", False)
    st.session_state.setdefault("trigger_export", False)

    st.session_state.setdefault("compare_a", "")
    st.session_state.setdefault("compare_b", "")

    # Batch selections (list for Streamlit safety)
    st.session_state.setdefault("reports_selected_ids", [])
    st.session_state.setdefault("genes_selected_ids", [])


def load_policy_evaluator() -> PolicyEvaluator:
    return PolicyEvaluator(str(POLICY_BASE_PATH), override_path=str(POLICY_OVERRIDE_PATH))


# -----------------------------
# Gene helpers
# -----------------------------
def ensure_default_gene(store: GeneStore) -> List[Gene]:
    genes = store.load() or []
    if genes:
        return genes
    g = store.new_gene("Gene-1", "ATGACCTTGGCTAACCTGTTACGATGGCCTTAA")
    store.save([g])
    st.session_state["selected_gene_id"] = g.gene_id
    return [g]


def get_active_gene(genes: List[Gene]) -> Optional[Gene]:
    if not genes:
        return None
    gid = st.session_state.get("selected_gene_id") or ""
    for g in genes:
        if g.gene_id == gid:
            return g
    st.session_state["selected_gene_id"] = genes[0].gene_id
    return genes[0]


def ensure_active_gene(genes: List[Gene], store: GeneStore) -> List[Gene]:
    if not genes:
        genes = ensure_default_gene(store)
    ag = get_active_gene(genes)
    if ag is None and genes:
        st.session_state["selected_gene_id"] = genes[0].gene_id
    return genes


def set_gene_kind_meta(g: Gene, kind: str) -> None:
    # backward compatible: meta dict varsa içine yaz
    meta = getattr(g, "meta", None)
    if isinstance(meta, dict):
        meta2 = dict(meta)
        meta2["kind"] = kind
        setattr(g, "meta", meta2)
    else:
        setattr(g, "meta", {"kind": kind})


# -----------------------------
# UI helpers
# -----------------------------
def _data_editor_supported() -> bool:
    return hasattr(st, "data_editor")


def render_stepper(active: str) -> None:
    steps = ["Parse", "Spec", "Apply", "Validate", "Report"]
    badges = []
    for s in steps:
        cls = "k-badge good" if s == active else "k-badge"
        badges.append(f"<span class='{cls}'>{s}</span>")
    st.markdown(
        "<div class='k-card-tight'><b>Pipeline</b>"
        "<div style='margin-top:6px; display:flex; gap:8px; flex-wrap:wrap;'>"
        + "".join(badges)
        + "</div></div>",
        unsafe_allow_html=True,
    )


def render_quickbar(genes: List[Gene]) -> None:
    c1, c2, c3 = st.columns([3.2, 1.6, 1.6], gap="small")
    with c1:
        st.text_input("Ara (gen/rapor)", key="global_search", placeholder="Gene adı / run_id / intent…")
    with c2:
        if st.button("Komut Paleti (⌘/Ctrl+K)", use_container_width=True):
            st.session_state["show_palette"] = not bool(st.session_state.get("show_palette"))
    with c3:
        st.markdown(
            "<div class='k-card-tight k-muted'>Kısayollar: ⌘/Ctrl+Enter Run • ⌘/Ctrl+S Save • ⌘/Ctrl+P Export</div>",
            unsafe_allow_html=True,
        )

    q = (st.session_state.get("global_search") or "").strip()
    if q:
        ql = q.lower()
        for g in genes:
            if ql in g.name.lower():
                st.session_state["selected_gene_id"] = g.gene_id
                st.session_state["global_search"] = ""
                nav_to("Workspace (Lab)")
                return

        runs = sort_runs_pinned_newest(load_runs_with_meta(RUNS_PATH, limit=2000))
        for r in runs:
            hay = f"{r.get('run_id','')} {r.get('intent','')} {r.get('gene_name','')}".lower()
            if ql in hay:
                st.session_state["selected_run_id"] = r.get("run_id", "")
                st.session_state["global_search"] = ""
                nav_to("Workspace (Lab)")
                return

    if st.session_state.get("show_palette"):
        with st.expander("Komut Paleti", expanded=True):
            cmds = [
                ("Workspace (Lab)", "Sayfaya git: Workspace"),
                ("Multi-Gene Editor", "Sayfaya git: Multi-Gene Editor"),
                ("Reports (History)", "Sayfaya git: Reports"),
                ("Compare", "Sayfaya git: Compare"),
                ("Policy Studio", "Sayfaya git: Policy Studio"),
                ("Diagnostics", "Sayfaya git: Diagnostics"),
                ("Settings", "Sayfaya git: Settings"),
                ("ACTION:Run", "Çalıştır (Run)"),
                ("ACTION:Save", "Save Run"),
                ("ACTION:Export", "Export (Bundle)"),
            ]
            idx = st.selectbox("Komut", options=list(range(len(cmds))), format_func=lambda i: cmds[i][1])
            if st.button("Uygula", type="primary"):
                cmd = cmds[int(idx)][0]
                st.session_state["show_palette"] = False
                if cmd == "ACTION:Run":
                    st.session_state["trigger_run"] = True
                    st.rerun()
                elif cmd == "ACTION:Save":
                    st.session_state["trigger_save"] = True
                    st.rerun()
                elif cmd == "ACTION:Export":
                    st.session_state["trigger_export"] = True
                    st.rerun()
                else:
                    nav_to(cmd)


# -----------------------------
# Pages
# -----------------------------
def page_workspace(genes: List[Gene], store: GeneStore, policy: PolicyEvaluator) -> None:
    st.markdown(
        "<div class='k-card'><div class='k-title'>Workspace</div><div class='k-muted'>Girdi → Çalıştır → Sonuç → Kaydet → Export</div></div>",
        unsafe_allow_html=True,
    )

    active_gene = get_active_gene(genes)
    if active_gene and not st.session_state.get("current_sequence"):
        st.session_state["current_sequence"] = active_gene.sequence

    api_base = st.session_state["api_base"]
    api_key = st.session_state["api_key"]
    timeout_s = float(st.session_state["timeout_s"])
    engine_mode = st.session_state["engine_mode"]
    enable_local_fallback = bool(st.session_state["enable_local_fallback"])

    # Inputs
    st.markdown("<div class='k-card'>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns([2.2, 2.2, 1.6], gap="medium")

    with c1:
        names = [f"{g.name} ({g.gene_id[:6]})" for g in genes]
        ids = [g.gene_id for g in genes]
        idx = ids.index(active_gene.gene_id) if active_gene and active_gene.gene_id in ids else 0
        pick = st.selectbox("Aktif gen", options=list(range(len(names))), index=idx, format_func=lambda i: names[i])
        st.session_state["selected_gene_id"] = ids[int(pick)]
        active_gene = get_active_gene(genes)

        seq_kind = st.selectbox("Sequence türü", ["dna", "rna"], index=0 if st.session_state["seq_kind"] == "dna" else 1)
        strict = st.toggle("Strict mode", value=bool(st.session_state["mode_strict"]))
        st.session_state["seq_kind"] = seq_kind
        st.session_state["mode_strict"] = bool(strict)

    with c2:
        st.text_input("Intent (TR serbest metin)", key="current_intent", placeholder="örn: ilk 5 baz sil")
        st.text_input("Rapor adı (opsiyonel)", key="current_report_name", placeholder="örn: Deneme-1")
        st.radio("View Mode", ["Editor Mode", "Run Mode", "Review Mode"], horizontal=True, key="view_mode")

    with c3:
        st.selectbox("Engine", ["Auto", "API", "Local"], key="engine_mode")
        st.toggle("API yoksa Local Fallback", key="enable_local_fallback")
        st.toggle("Raporları kaydet (tarihçe)", key="save_history")
        st.toggle("Raporlarda tam DNA sakla", key="store_full_sequence")

    st.markdown("<div class='k-title' style='margin-top:10px;'>DNA/RNA Sequence</div>", unsafe_allow_html=True)
    st.text_area("DNA/RNA Sequence", key="current_sequence", height=200, label_visibility="collapsed")

    val = validate_iupac(
        st.session_state["current_sequence"],
        kind=st.session_state["seq_kind"],
        strict=bool(st.session_state["mode_strict"]),
    )

    if not val.seq:
        st.warning("Sequence boş.")
    elif not val.ok:
        pos, ch = val.invalid_positions[0]
        st.error(f"Geçersiz karakter: pozisyon {pos} -> '{ch}'")
    else:
        i1, i2, i3 = st.columns([1.2, 1.2, 2.6], gap="small")
        i1.markdown(f"<div class='k-card-tight'><b>Len</b><div class='k-mono'>{val.length}</div></div>", unsafe_allow_html=True)
        i2.markdown(f"<div class='k-card-tight'><b>GC%</b><div class='k-mono'>{val.gc_percent:.1f}%</div></div>", unsafe_allow_html=True)
        i3.markdown(
            f"<div class='k-card-tight'><b>Uyarılar</b><div class='k-muted'>{' | '.join(val.warnings) if val.warnings else '—'}</div></div>",
            unsafe_allow_html=True,
        )

    with st.expander("Chunk görünümü", expanded=False):
        st.code(format_chunked(val.seq, width=60, with_pos=True), language="text")

    st.markdown("</div>", unsafe_allow_html=True)

    # Engine status
    api_ok, _, api_err = cached_api_health(api_base, timeout_s, api_key)
    api_caps_ok, api_caps, api_caps_err = cached_api_capabilities(api_base, api_key)
    engine = engine_mode if engine_mode != "Auto" else ("API" if api_ok else "Local")

    if engine == "API" and not api_ok and not enable_local_fallback:
        st.error(f"API sağlıksız ve Local Fallback kapalı. Detay: {api_err}")
        return

    if engine == "Local" or (engine == "API" and not api_ok and enable_local_fallback):
        st.warning("API erişilemiyor/sağlıksız → Local fallback ile çalışılıyor.", icon="⚠️")
    elif engine == "API" and api_ok:
        st.success("API healthy → API mode aktif.", icon="✅")

    # Toolbar
    st.markdown("<div class='k-card'>", unsafe_allow_html=True)
    st.markdown("<div class='k-title'>Kontrol Paneli</div>", unsafe_allow_html=True)
    t = st.columns([1, 1, 1, 1, 1, 1, 1, 1, 1, 1], gap="small")
    run_btn = t[0].button("Run", type="primary", use_container_width=True)
    spec_btn = t[1].button("Generate Spec", use_container_width=True)
    apply_btn = t[2].button("Apply Spec", use_container_width=True)
    validate_btn = t[3].button("Validate", use_container_width=True)
    compare_btn = t[4].button("Compare", use_container_width=True)
    export_btn = t[5].button("Export", use_container_width=True)
    save_btn = t[6].button("Save Run", use_container_width=True)
    clear_btn = t[7].button("Clear", use_container_width=True)
    settings_btn = t[8].button("Settings", use_container_width=True)
    diag_btn = t[9].button("Diagnostics", use_container_width=True)

    if st.session_state.get("trigger_run"):
        run_btn = True
        st.session_state["trigger_run"] = False
    if st.session_state.get("trigger_save"):
        save_btn = True
        st.session_state["trigger_save"] = False
    if st.session_state.get("trigger_export"):
        export_btn = True
        st.session_state["trigger_export"] = False

    if settings_btn:
        nav_to("Settings")
    if diag_btn:
        nav_to("Diagnostics")
    if clear_btn:
        st.session_state["current_spec"] = None
        st.session_state["current_result"] = None
        st.session_state["last_run_full"] = None
        st.success("Workspace temizlendi.")
        st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)
    render_stepper("Report" if st.session_state.get("current_result") else ("Spec" if st.session_state.get("current_spec") else "Parse"))

    # Preconditions
    if (run_btn or spec_btn or apply_btn or validate_btn) and (not val.seq):
        st.error("Sequence boş.")
        return
    if (run_btn or spec_btn or apply_btn or validate_btn) and (not val.ok):
        st.error("Sequence invalid.")
        return

    mode_str = "strict" if bool(st.session_state["mode_strict"]) else "lenient"
    intent = st.session_state.get("current_intent") or ""

    def spec_local() -> Dict[str, Any]:
        return intent_to_editspec(intent, strict_mode=bool(st.session_state["mode_strict"]))

    def apply_local(spec: Dict[str, Any]) -> Dict[str, Any]:
        return apply_editspec(val.seq, spec, strict_mode=bool(st.session_state["mode_strict"]), policy=policy)

    def run_local() -> Dict[str, Any]:
        return run_intent(val.seq, intent, strict_mode=bool(st.session_state["mode_strict"]), policy=policy)

    # Spec
    if spec_btn:
        with st.spinner("Spec üretiliyor..."):
            obj = None
            err = None
            if engine == "API" and api_ok:
                obj, err, _ = api_post_raw(api_base, "/nl/spec", timeout_s=timeout_s, api_key=api_key, body={"intent": intent, "mode": mode_str})
            if obj is None and enable_local_fallback:
                obj, err = spec_local(), None
                st.info("Spec local üretildi (fallback).")
            if err:
                st.error(f"Spec üretilemedi: {err}")
            else:
                st.session_state["current_spec"] = obj
                st.success("Spec hazır.")

    # Apply
    if apply_btn:
        spec = st.session_state.get("current_spec")
        if not spec:
            st.error("Spec yok. Önce Generate Spec.")
        else:
            with st.spinner("Spec uygulanıyor..."):
                obj = None
                err = None
                if engine == "API" and api_ok:
                    obj, err, _ = api_post_raw(
                        api_base,
                        "/edit/apply",
                        timeout_s=timeout_s,
                        api_key=api_key,
                        body={"sequence": val.seq, "spec": spec, "mode": mode_str},
                    )
                if obj is None and enable_local_fallback:
                    obj, err = apply_local(spec), None
                    st.info("Apply local yapıldı (fallback).")
                if err:
                    st.error(f"Apply başarısız: {err}")
                else:
                    st.session_state["current_result"] = obj
                    st.success("Uygulandı.")

    # Validate (local deterministic)
    if validate_btn:
        spec = st.session_state.get("current_spec")
        if not spec:
            st.error("Spec yok.")
        else:
            obj = apply_local(spec)
            errs = obj.get("errors") or []
            if errs:
                st.warning("Validasyon uyarıları/hataları var.")
                st.json(errs)
            else:
                st.success("Validasyon OK.")

    # Run
    if run_btn:
        with st.spinner("Çalıştırılıyor..."):
            t0 = time.time()
            obj = None
            err = None
            transport = "local"
            if engine == "API" and api_ok:
                obj, err, transport = api_run_body_first(
                    api_base,
                    sequence=val.seq,
                    intent=intent,
                    mode=mode_str,
                    timeout_s=timeout_s,
                    api_key=api_key,
                )
            if obj is None and enable_local_fallback:
                obj, err, transport = run_local(), None, "local"
            latency_ms = (time.time() - t0) * 1000.0

            if err:
                st.error(f"Run başarısız: {err}")
            else:
                if transport == "legacy_query":
                    st.info("Not: /run legacy query fallback kullanıldı (backend eski olabilir).", icon="ℹ️")

                before = obj.get("before") or val.seq
                after = obj.get("after") or before
                added, removed, changed = diff_stats(before, after)

                pol = obj.get("policy") or {}
                policy_allowed = pol.get("allowed") if isinstance(pol, dict) else obj.get("policy_allowed")
                policy_reason = pol.get("reason") if isinstance(pol, dict) else obj.get("policy_reason")

                run_id = obj.get("run_id") or obj.get("request_id") or datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
                run_rec = {
                    "run_id": run_id,
                    "ts_iso": now_iso_utc(),
                    "gene_id": active_gene.gene_id if active_gene else "",
                    "gene_name": active_gene.name if active_gene else "",
                    "intent": intent,
                    "mode": mode_str,
                    "report_name": st.session_state.get("current_report_name") or "",
                    "before": before if bool(st.session_state["store_full_sequence"]) else "",
                    "after": after if bool(st.session_state["store_full_sequence"]) else "",
                    "before_len": len(before),
                    "after_len": len(after),
                    "added": added,
                    "removed": removed,
                    "changed": changed,
                    "latency_ms": round(latency_ms, 2),
                    "status": "success" if (not obj.get("errors")) else "warning",
                    "errors": obj.get("errors") or [],
                    "spec": obj.get("spec") or st.session_state.get("current_spec") or {},
                    "policy_allowed": policy_allowed,
                    "policy_reason": policy_reason,
                    "raw": obj,
                }

                st.session_state["current_result"] = obj
                st.session_state["last_run_full"] = run_rec
                st.session_state["selected_run_id"] = run_id
                st.success("Run tamamlandı.")

                if bool(st.session_state["save_history"]):
                    append_run(RUNS_PATH, run_rec)

    # Save
    if save_btn:
        last = st.session_state.get("last_run_full")
        if not last:
            st.error("Kaydedilecek run yok.")
        else:
            append_run(RUNS_PATH, last)
            st.success("Run kaydedildi.")

    # Export
    if export_btn:
        last = st.session_state.get("last_run_full")
        if not last:
            st.error("Export edilecek run yok.")
        else:
            st.markdown("<div class='k-card'><div class='k-title'>Export</div></div>", unsafe_allow_html=True)
            st.download_button("JSON indir", data=json.dumps(last, ensure_ascii=False, indent=2).encode("utf-8"), file_name="run.json", mime="application/json")
            st.download_button("Excel indir (.xlsx)", data=make_xlsx_bytes(last), file_name="run.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            st.download_button("PDF indir", data=make_pdf_bytes(last), file_name="run.pdf", mime="application/pdf")
            st.download_button("Bundle ZIP indir", data=make_bundle_zip(last), file_name="export_bundle.zip", mime="application/zip")

    # Compare
    if compare_btn:
        st.session_state["compare_a"] = st.session_state.get("selected_run_id") or ""
        nav_to("Compare")

    # Result view
    if st.session_state["view_mode"] in ("Run Mode", "Review Mode"):
        st.markdown("<div class='k-card'><div class='k-title'>Sonuç</div><div class='k-muted'>Before/After + diff</div></div>", unsafe_allow_html=True)
        last = st.session_state.get("last_run_full")
        if not last:
            st.info("Henüz bir run yok.")
        else:
            before = last.get("before") or ""
            after = last.get("after") or ""
            ca, cb = st.columns(2, gap="medium")
            ca.text_area("Before", value=before, height=170)
            cb.text_area("After", value=after, height=170)

            html1, reason1 = inline_diff_html(before, after)
            html2, reason2 = side_by_side_diff_html(before, after)
            t1, t2 = st.tabs(["INLINE Diff", "Side-by-side"])
            with t1:
                st.markdown(html1, unsafe_allow_html=True) if html1 else st.warning(reason1)
            with t2:
                st.markdown(html2, unsafe_allow_html=True) if html2 else st.warning(reason2)


def page_multigene(genes: List[Gene], store: GeneStore) -> List[Gene]:
    st.markdown("<div class='k-card'><div class='k-title'>Multi-Gene Editor</div><div class='k-muted'>Liste + edit + BATCH</div></div>", unsafe_allow_html=True)

    left, mid, right = st.columns([1.9, 3.0, 1.6], gap="medium")

    with left:
        st.text_input("Ara", key="gene_search", placeholder="Gen adı ara...")
        q = (st.session_state.get("gene_search") or "").strip().lower()
        filtered = [g for g in genes if q in g.name.lower()] if q else genes
        if not filtered:
            st.info("Eşleşme yok.")
            filtered = genes

        # active gene selector
        ag = get_active_gene(genes)
        labels = [f"{g.name} ({g.gene_id[:6]})" for g in filtered]
        ids = [g.gene_id for g in filtered]
        idx = ids.index(ag.gene_id) if ag and ag.gene_id in ids else 0
        pick = st.selectbox("Aktif Gen", options=list(range(len(filtered))), index=idx, format_func=lambda i: labels[i])
        st.session_state["selected_gene_id"] = ids[int(pick)]

        st.divider()

        # multi-select
        selected = set(st.session_state.get("genes_selected_ids") or [])
        rows: List[Dict[str, Any]] = []
        for g in filtered[:MAX_TABLE_ROWS]:
            rows.append({"selected": g.gene_id in selected, "name": g.name, "len": len("".join((g.sequence or "").split())), "gene_id": g.gene_id})

        if _data_editor_supported():
            edited = st.data_editor(
                rows,
                hide_index=True,
                use_container_width=True,
                height=280,
                key="genes_table",
                disabled=["name", "len", "gene_id"],
                column_config={
                    "selected": st.column_config.CheckboxColumn("✓", width="small"),
                    "name": st.column_config.TextColumn("Gene", width="medium"),
                    "len": st.column_config.NumberColumn("Len", width="small"),
                    "gene_id": st.column_config.TextColumn("ID", width="small"),
                },
            )
            st.session_state["genes_selected_ids"] = [r["gene_id"] for r in edited if r.get("selected")]
        else:
            new_sel = []
            for r in rows:
                if st.checkbox(f'{r["name"]} ({r["len"]})', value=bool(r["selected"]), key=f"gck_{r['gene_id']}"):
                    new_sel.append(r["gene_id"])
            st.session_state["genes_selected_ids"] = new_sel

        sel_ids = list(st.session_state.get("genes_selected_ids") or [])
        if sel_ids:
            st.markdown("<div class='k-card-tight'><b>BATCH</b> — Toplu İşlem Çubuğu</div>", unsafe_allow_html=True)
            c1, c2 = st.columns([1.6, 1.0], gap="small")
            c1.markdown(f"<div class='k-muted'>✓ <b>{len(sel_ids)}</b> gen seçili</div>", unsafe_allow_html=True)
            if c2.button("Seçimi temizle", use_container_width=True):
                st.session_state["genes_selected_ids"] = []
                st.rerun()

            action = st.selectbox(
                "Toplu İşlemler ▾",
                options=["—", "Notes append", "Normalize sequences", "Set kind (meta)", "Validate (summary)", "Export FASTA", "Delete (hard)"],
                label_visibility="collapsed",
                key="genes_bulk_action",
            )

            sel_set = set(sel_ids)
            selected_genes = [g for g in genes if g.gene_id in sel_set]

            if action == "Notes append":
                txt = st.text_input("Eklenecek not", key="bulk_notes_append", placeholder="örn: batch-1")
                if st.button("Uygula (append)", type="primary", use_container_width=True):
                    for g in selected_genes:
                        cur = getattr(g, "notes", "") or ""
                        add = txt.strip()
                        if not add:
                            continue
                        setattr(g, "notes", (cur + ("\n" if cur else "") + add).strip())
                    store.save(genes)
                    st.success("Notlar eklendi.")
                    st.rerun()

            elif action == "Normalize sequences":
                st.caption("Uppercase + whitespace temizle")
                if st.button("Uygula (normalize)", type="primary", use_container_width=True):
                    for g in selected_genes:
                        setattr(g, "sequence", "".join((g.sequence or "").split()).upper())
                    store.save(genes)
                    st.success("Normalize tamam.")
                    st.rerun()

            elif action == "Set kind (meta)":
                kind = st.selectbox("kind", ["dna", "rna"], key="bulk_kind")
                if st.button("Uygula (set kind)", type="primary", use_container_width=True):
                    for g in selected_genes:
                        set_gene_kind_meta(g, kind)
                    store.save(genes)
                    st.success("Kind meta set edildi.")
                    st.rerun()

            elif action == "Validate (summary)":
                if st.button("Çalıştır (validate)", type="primary", use_container_width=True):
                    ok_n = 0
                    bad_n = 0
                    examples: List[str] = []
                    for g in selected_genes:
                        v = validate_iupac(g.sequence or "", strict=False)
                        if v.ok and v.seq:
                            ok_n += 1
                        else:
                            bad_n += 1
                            if v.invalid_positions:
                                pos, ch = v.invalid_positions[0]
                                examples.append(f"{g.name}: pos {pos} '{ch}'")
                    st.markdown(f"✅ OK: **{ok_n}**  |  ❌ Hatalı: **{bad_n}**")
                    if examples:
                        st.warning("İlk örnek hatalar:")
                        st.code("\n".join(examples[:5]), language="text")

            elif action == "Export FASTA":
                fasta = to_fasta([(g.name, g.sequence or "") for g in selected_genes]).encode("utf-8")
                st.download_button("Seçili genler FASTA indir", data=fasta, file_name="selected_genes.fasta", mime="text/plain", use_container_width=True)

            elif action == "Delete (hard)":
                with st.expander("Tehlikeli işlem — Hard delete", expanded=False):
                    confirm = st.checkbox("Onaylıyorum (hard delete)", key="bulk_gene_delete_confirm")
                    if st.button("Sil", type="primary", disabled=not confirm, use_container_width=True):
                        if len(selected_genes) >= len(genes):
                            st.error("Tüm genleri silemezsin. En az 1 gen kalmalı.")
                        else:
                            genes = [g for g in genes if g.gene_id not in sel_set]
                            genes = ensure_active_gene(genes, store)
                            store.save(genes)
                            st.session_state["genes_selected_ids"] = []
                            st.success("Silindi.")
                            st.rerun()

        st.divider()

        # add/duplicate/delete single
        b1, b2 = st.columns(2, gap="small")
        if b1.button("➕ Ekle", use_container_width=True):
            ng = store.new_gene(f"Gene-{len(genes)+1}", "")
            genes = genes + [ng]
            store.save(genes)
            st.session_state["selected_gene_id"] = ng.gene_id
            st.rerun()
        if b2.button("🧬 Duplike", use_container_width=True):
            ag = get_active_gene(genes)
            if ag:
                ng = store.new_gene(ag.name + " Copy", ag.sequence)
                genes = genes + [ng]
                store.save(genes)
                st.session_state["selected_gene_id"] = ng.gene_id
                st.rerun()

        b3, b4 = st.columns(2, gap="small")
        if b3.button("🗑 Sil (hard)", use_container_width=True):
            ag = get_active_gene(genes)
            if ag:
                if len(genes) <= 1:
                    st.error("Son gene silinemez. Önce yeni gene ekle.")
                else:
                    genes = [g for g in genes if g.gene_id != ag.gene_id]
                    genes = ensure_active_gene(genes, store)
                    store.save(genes)
                    st.rerun()
        if b4.button("📋 Kopyala", use_container_width=True):
            ag = get_active_gene(genes)
            if ag:
                st.session_state["clipboard_sequence"] = ag.sequence
                st.info("Sekans panoya hazır (UI içi).")

        st.markdown("**Import**")
        up = st.file_uploader("FASTA / txt", type=["fasta", "fa", "txt"], label_visibility="collapsed")
        if up is not None:
            txt = up.read().decode("utf-8", errors="ignore")
            recs = parse_fasta(txt)
            if recs:
                for r in recs:
                    genes.append(store.new_gene(r["name"], r["sequence"]))
                store.save(genes)
                st.rerun()

    with mid:
        ag = get_active_gene(genes)
        if not ag:
            st.info("Gen yok.")
        else:
            st.text_input("Gen adı", value=ag.name, key="mg_name")
            st.text_area("Sekans", value=ag.sequence, height=260, key="mg_seq")
            st.text_area("Notlar", value=getattr(ag, "notes", "") or "", height=120, key="mg_notes")

            if st.button("Kaydet", type="primary"):
                ag.name = (st.session_state["mg_name"].strip() or ag.name)
                ag.sequence = st.session_state["mg_seq"]
                setattr(ag, "notes", st.session_state["mg_notes"])
                store.save(genes)
                st.success("Kaydedildi.")

            with st.expander("Chunk görünümü", expanded=False):
                v = validate_iupac(ag.sequence, strict=False)
                st.code(format_chunked(v.seq, width=80, with_pos=True), language="text")

    with right:
        ag = get_active_gene(genes)
        if ag:
            v = validate_iupac(ag.sequence, strict=False)
            st.markdown("<div class='k-card-tight'><b>Meta</b></div>", unsafe_allow_html=True)
            st.markdown(
                f"<div class='k-card-tight k-muted'>Len: <b>{v.length}</b><br/>GC%: <b>{v.gc_percent:.1f}%</b><br/>Kind: <b>{v.kind}</b></div>",
                unsafe_allow_html=True,
            )
            if v.invalid_positions:
                pos, ch = v.invalid_positions[0]
                st.error(f"Geçersiz: {pos} '{ch}'")

            st.markdown("**Export**")
            st.download_button(
                "Seçili gen FASTA",
                data=to_fasta([(ag.name, ag.sequence)]).encode("utf-8"),
                file_name=f"{ag.name}.fasta",
                mime="text/plain",
                use_container_width=True,
            )
            st.download_button(
                "Tüm genler FASTA",
                data=to_fasta([(g.name, g.sequence) for g in genes]).encode("utf-8"),
                file_name="genes.fasta",
                mime="text/plain",
                use_container_width=True,
            )

    return genes


def page_reports() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Reports (History)</div><div class='k-muted'>Arama / filtre / BATCH / export</div></div>", unsafe_allow_html=True)

    runs_all = sort_runs_pinned_newest(load_runs_with_meta(RUNS_PATH, limit=5000))
    if not runs_all:
        st.info("Henüz rapor yok.")
        return

    c1, c2, c3, c4 = st.columns([2.2, 1.0, 1.2, 1.2], gap="small")
    q = c1.text_input("Ara (gen/intent/run_id)", value="", placeholder="örn: Gene-1 veya run_id")
    status = c2.selectbox("Durum", ["all", "success", "warning", "error"], index=0)
    pinned_only = c3.toggle("Sadece pinned", value=False)
    include_deleted = c4.toggle("Deleted göster", value=False)

    filtered = filter_runs(runs_all, q=q, status=status, pinned_only=pinned_only, include_deleted=include_deleted, include_archived=True)
    st.markdown(f"<div class='k-card-tight k-muted'>Gösterilen: <b>{len(filtered)}</b> / {len(runs_all)} (max {MAX_TABLE_ROWS})</div>", unsafe_allow_html=True)

    options = filtered[:MAX_TABLE_ROWS]
    selected = set(st.session_state.get("reports_selected_ids") or [])

    rows: List[Dict[str, Any]] = []
    for r in options:
        rid = r.get("run_id", "")
        rows.append(
            {
                "selected": rid in selected,
                "pin": "⭐" if bool(r.get("pinned")) else "",
                "del": "🗑" if bool(r.get("deleted")) else "",
                "ts": r.get("ts_iso", ""),
                "gene": r.get("gene_name", ""),
                "intent": (r.get("intent", "") or "")[:80],
                "status": r.get("status", ""),
                "run_id": rid,
            }
        )

    if _data_editor_supported():
        edited = st.data_editor(
            rows,
            hide_index=True,
            use_container_width=True,
            height=360,
            key="reports_table",
            disabled=["pin", "del", "ts", "gene", "intent", "status", "run_id"],
            column_config={
                "selected": st.column_config.CheckboxColumn("✓", width="small"),
                "pin": st.column_config.TextColumn("Pin", width="small"),
                "del": st.column_config.TextColumn("Del", width="small"),
                "ts": st.column_config.TextColumn("TS", width="medium"),
                "gene": st.column_config.TextColumn("Gene", width="medium"),
                "intent": st.column_config.TextColumn("Intent", width="large"),
                "status": st.column_config.TextColumn("Status", width="small"),
                "run_id": st.column_config.TextColumn("RunID", width="small"),
            },
        )
        st.session_state["reports_selected_ids"] = [r["run_id"] for r in edited if r.get("selected")]
    else:
        new_sel = []
        for r in rows:
            label = f'{r["pin"]}{r["del"]} {r["ts"]} | {r["gene"]} | {r["intent"][:40]} | {r["run_id"][:8]}'
            if st.checkbox(label, value=bool(r["selected"]), key=f"rep_ck_{r['run_id']}"):
                new_sel.append(r["run_id"])
        st.session_state["reports_selected_ids"] = new_sel

    sel_ids = list(st.session_state.get("reports_selected_ids") or [])
    sel_set = set(sel_ids)
    sel_runs = [r for r in runs_all if (r.get("run_id") or "") in sel_set]

    # Bulk Action Bar
    if sel_ids:
        st.markdown("<div class='k-card-tight'><b>BATCH</b> — Toplu İşlem Çubuğu</div>", unsafe_allow_html=True)
        a1, a2, a3 = st.columns([2.0, 1.0, 1.4], gap="small")
        a1.markdown(f"<div class='k-muted'>✓ <b>{len(sel_ids)}</b> rapor seçili</div>", unsafe_allow_html=True)
        if a2.button("Seçimi temizle", use_container_width=True):
            st.session_state["reports_selected_ids"] = []
            st.rerun()

        bulk = a3.selectbox(
            "Toplu İşlemler ▾",
            options=[
                "—",
                "Pin (bulk)",
                "Unpin (bulk)",
                "Export: Combined Bundle ZIP",
                "Export: Selected JSONL",
                "Compare selected (A,B)",
                "Archive (soft)",
                "Delete (soft)",
            ],
            label_visibility="collapsed",
            key="reports_bulk_action",
        )

        if bulk in ("Pin (bulk)", "Unpin (bulk)"):
            target = bulk.startswith("Pin")
            if st.button("Uygula", type="primary"):
                for rid in sel_ids:
                    append_run(RUNS_PATH, {"run_id": rid, "ts_iso": now_iso_utc(), "pinned": target, "_type": "meta"})
                st.success(f"{len(sel_ids)} rapor için pinned={target} güncellendi.")
                st.rerun()

        elif bulk == "Export: Combined Bundle ZIP":
            st.download_button(
                "Combined Bundle ZIP indir",
                data=make_bundle_zip_many(sel_runs),
                file_name="selected_runs_bundle.zip",
                mime="application/zip",
                use_container_width=True,
            )

        elif bulk == "Export: Selected JSONL":
            st.download_button(
                "Selected JSONL indir",
                data=make_jsonl_bytes(sel_runs),
                file_name="selected_runs.jsonl",
                mime="application/jsonl",
                use_container_width=True,
            )

        elif bulk == "Compare selected (A,B)":
            if len(sel_ids) < 2:
                st.info("Compare için en az 2 rapor seç.")
            else:
                if len(sel_ids) == 2:
                    a_id, b_id = sel_ids[0], sel_ids[1]
                else:
                    cA, cB = st.columns(2, gap="small")
                    a_id = cA.selectbox("A", options=sel_ids, index=0, key="bulk_cmp_a")
                    b_candidates = [x for x in sel_ids if x != a_id] or sel_ids
                    b_id = cB.selectbox("B", options=b_candidates, index=0, key="bulk_cmp_b")
                if st.button("Compare (A,B)", type="primary"):
                    st.session_state["compare_a"] = a_id
                    st.session_state["compare_b"] = b_id
                    nav_to("Compare")

        elif bulk in ("Archive (soft)", "Delete (soft)"):
            flag = "archived" if bulk.startswith("Archive") else "deleted"
            with st.expander("Tehlikeli işlem — iki aşamalı onay", expanded=False):
                st.caption(f"Seçilen raporlara meta '{flag}: true' yazılacak (soft).")
                confirm = st.checkbox("Onaylıyorum", key=f"bulk_confirm_{flag}")
                if st.button("Uygula (soft)", type="primary", disabled=not confirm):
                    for rid in sel_ids:
                        append_run(RUNS_PATH, {"run_id": rid, "ts_iso": now_iso_utc(), flag: True, "_type": "meta"})
                    st.success(f"{len(sel_ids)} rapor için {flag}=true işlendi.")
                    st.session_state["reports_selected_ids"] = []
                    st.rerun()

    # Single-run preview + exports
    st.markdown("<div class='k-card'><div class='k-title'>Preview / Export (tek rapor)</div></div>", unsafe_allow_html=True)
    if not options:
        st.info("Filtreye uygun rapor yok.")
        return

    ids = [r.get("run_id", "") for r in options if r.get("run_id")]
    default_id = st.session_state.get("selected_run_id") or ids[0]
    if default_id not in ids:
        default_id = ids[0]
    idx = ids.index(default_id)

    labels = [f"{r.get('ts_iso','')} | {r.get('gene_name','')} | {str(r.get('intent',''))[:40]} | {str(r.get('run_id',''))[:8]}" for r in options]
    pick_idx = st.selectbox("Rapor seç", options=list(range(len(options))), index=idx, format_func=lambda i: labels[i])
    r = options[int(pick_idx)]
    st.session_state["selected_run_id"] = r.get("run_id", "")

    st.download_button("JSON indir", data=json.dumps(r, ensure_ascii=False, indent=2).encode("utf-8"), file_name=f"{r.get('run_id','run')}.json", mime="application/json", use_container_width=True)
    st.download_button("Excel indir (.xlsx)", data=make_xlsx_bytes(r), file_name=f"{r.get('run_id','run')}.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)
    st.download_button("PDF indir", data=make_pdf_bytes(r), file_name=f"{r.get('run_id','run')}.pdf", mime="application/pdf", use_container_width=True)
    st.download_button("Bundle ZIP indir", data=make_bundle_zip(r), file_name=f"{r.get('run_id','run')}_bundle.zip", mime="application/zip", use_container_width=True)

    before = (r.get("before") or (r.get("raw") or {}).get("before") or "")
    after = (r.get("after") or (r.get("raw") or {}).get("after") or "")
    if not before and not after:
        st.warning("Bu raporda full sequence saklanmamış olabilir (store_full_sequence kapalıydı). Diff sınırlı olur.")

    t1, t2 = st.tabs(["INLINE", "SBS"])
    with t1:
        html1, reason1 = inline_diff_html(before, after)
        st.markdown(html1, unsafe_allow_html=True) if html1 else st.warning(reason1)
    with t2:
        html2, reason2 = side_by_side_diff_html(before, after)
        st.markdown(html2, unsafe_allow_html=True) if html2 else st.warning(reason2)


def page_compare() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Compare Runs</div><div class='k-muted'>İki raporu seç → diff</div></div>", unsafe_allow_html=True)

    runs = sort_runs_pinned_newest(load_runs_with_meta(RUNS_PATH, limit=4000))
    runs = [r for r in runs if not bool(r.get("deleted"))]
    if len(runs) < 2:
        st.info("Compare için en az 2 rapor gerekli.")
        return

    pick = runs[:MAX_TABLE_ROWS]
    labels = [
        f"{('⭐' if bool(r.get('pinned')) else '')}{r.get('ts_iso','')} | {r.get('gene_name','')} | {str(r.get('intent',''))[:40]} | {str(r.get('run_id',''))[:8]}"
        for r in pick
    ]
    ids = [r.get("run_id", "") for r in pick]

    a_id = st.session_state.get("compare_a") or ids[0]
    b_id = st.session_state.get("compare_b") or (ids[1] if len(ids) > 1 else ids[0])
    a_idx = ids.index(a_id) if a_id in ids else 0
    b_idx = ids.index(b_id) if b_id in ids else 1

    c1, c2 = st.columns(2, gap="medium")
    with c1:
        a_sel = st.selectbox("Run A", options=list(range(len(labels))), index=a_idx, format_func=lambda i: labels[i])
    with c2:
        b_sel = st.selectbox("Run B", options=list(range(len(labels))), index=b_idx, format_func=lambda i: labels[i])

    a = pick[int(a_sel)]
    b = pick[int(b_sel)]
    st.session_state["compare_a"] = a.get("run_id", "")
    st.session_state["compare_b"] = b.get("run_id", "")

    a_after = (a.get("after") or (a.get("raw") or {}).get("after") or "")
    b_after = (b.get("after") or (b.get("raw") or {}).get("after") or "")

    if not a_after or not b_after:
        st.warning("Compare için gerekli full 'after' sequence yok. (store_full_sequence kapalı olabilir.)")

    html1, reason1 = inline_diff_html(a_after, b_after)
    html2, reason2 = side_by_side_diff_html(a_after, b_after)

    t1, t2 = st.tabs(["INLINE", "SBS"])
    with t1:
        st.markdown(html1, unsafe_allow_html=True) if html1 else st.warning(f"Diff üretilemedi: {reason1}")
    with t2:
        st.markdown(html2, unsafe_allow_html=True) if html2 else st.warning(f"SBS diff üretilemedi: {reason2}")


def page_policy(policy: PolicyEvaluator) -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Policy Studio</div><div class='k-muted'>Override edit + simulate</div></div>", unsafe_allow_html=True)

    base_text = POLICY_BASE_PATH.read_text(encoding="utf-8") if POLICY_BASE_PATH.exists() else "{}"
    override_text = POLICY_OVERRIDE_PATH.read_text(encoding="utf-8") if POLICY_OVERRIDE_PATH.exists() else ""

    col1, col2 = st.columns(2, gap="medium")
    with col1:
        st.markdown("**Base Policy (read-only)**")
        st.code(base_text, language="json")
    with col2:
        st.markdown("**Override Policy (editable)**")
        txt = st.text_area("Override", value=override_text, height=240, key="policy_override_edit")
        bsave, bclear = st.columns(2)
        if bsave.button("Kaydet", type="primary"):
            try:
                json.loads(txt or "{}")
                POLICY_OVERRIDE_PATH.parent.mkdir(parents=True, exist_ok=True)
                POLICY_OVERRIDE_PATH.write_text(txt or "{}", encoding="utf-8")
                st.success("Override kaydedildi.")
            except Exception as e:
                st.error(f"JSON geçersiz: {e}")
        if bclear.button("Sıfırla"):
            if POLICY_OVERRIDE_PATH.exists():
                POLICY_OVERRIDE_PATH.unlink()
            st.success("Override silindi.")


def page_diagnostics() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Diagnostics</div><div class='k-muted'>Health check + bağlantı</div></div>", unsafe_allow_html=True)
    api_base = st.session_state["api_base"]
    api_key = st.session_state["api_key"]
    timeout_s = float(st.session_state["timeout_s"])
    if st.button("Test Connection (/health)", type="primary"):
        ok, obj, err = cached_api_health(api_base, timeout_s, api_key)
        if err:
            st.error(err)
        else:
            st.success("OK" if ok else "NOT OK")
            st.json(obj)


def page_settings() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Settings</div><div class='k-muted'>API + timeout + storage</div></div>", unsafe_allow_html=True)
    st.text_input("API Base", key="api_base")
    st.text_input("API Key (opsiyonel)", key="api_key", type="password")
    st.number_input("HTTP Timeout (sn)", min_value=1.0, max_value=60.0, step=1.0, key="timeout_s")
    st.markdown(
        f"<div class='k-card-tight k-muted'>Runs Path: <b>{RUNS_PATH}</b><br/>Genes Path: <b>{GENES_PATH}</b></div>",
        unsafe_allow_html=True,
    )


def main() -> None:
    st.set_page_config(page_title="Katopu GenLab (Ultra)", layout="wide")
    ss_init()
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)

    store = GeneStore(GENES_PATH)
    genes = ensure_default_gene(store)
    genes = ensure_active_gene(genes, store)
    policy = load_policy_evaluator()

    # Sidebar (NAV FIX: deferred nav BEFORE radio key="page")
    with st.sidebar:
        st.markdown("### Katopu GenLab")
        st.caption(f"API: {'✅ OK' if api_ok else '❌ ERROR'}")
        if api_ok and isinstance(api_health, dict):
            meta = api_health.get("_meta", {}) if isinstance(api_health.get("_meta", {}), dict) else {}
            if meta:
                st.caption(f"Contract: {meta.get('contract','?')} | Engine: {meta.get('engine','?')}")
        if 'api_caps_ok' in globals() and api_caps_ok:
            feats = (api_caps.get("features") or {}) if isinstance(api_caps, dict) else {}
            if feats:
                st.caption("API özellikleri: " + ", ".join([k for k,v in feats.items() if v]))
        elif 'api_caps_err' in globals() and api_ok and api_caps_err:
            st.caption(f"capabilities okunamadı: {api_caps_err}")
        st.markdown(f"<div class='k-muted'>v{APP_VERSION} • contract {CONTRACT_VERSION}</div>", unsafe_allow_html=True)

        pages = [
            "Workspace (Lab)",
            "Multi-Gene Editor",
            "Reports (History)",
            "Compare",
            "Policy Studio",
            "Diagnostics",
            "Settings",
        ]

        nav = st.session_state.get("nav_to")
        if nav:
            st.session_state["page"] = nav
            st.session_state["nav_to"] = None

        st.radio("Menu", pages, key="page", label_visibility="collapsed")
        st.divider()

        api_ok, _, _ = cached_api_health(st.session_state["api_base"], float(st.session_state["timeout_s"]), st.session_state["api_key"])
        st.markdown(f"**API Healthy:** {'✅' if api_ok else '❌'}")

    # Shortcuts
    inject_shortcuts_js()
    actions = handle_shortcut_actions()
    if actions.get("palette"):
        st.session_state["show_palette"] = True
    if actions.get("run"):
        st.session_state["trigger_run"] = True
    if actions.get("save"):
        st.session_state["trigger_save"] = True
    if actions.get("export"):
        st.session_state["trigger_export"] = True

    ag = get_active_gene(genes)
    env_label = os.environ.get("KATOPU_ENV", "local/dev").strip()
    st.markdown(topbar_html("Katopu GenLab — Ultra", env_label, ag.name if ag else "—"), unsafe_allow_html=True)

    render_quickbar(genes)

    page = st.session_state.get("page")
    if page == "Workspace (Lab)":
        page_workspace(genes, store, policy)
    elif page == "Multi-Gene Editor":
        genes = page_multigene(genes, store)
    elif page == "Reports (History)":
        page_reports()
    elif page == "Compare":
        page_compare()
    elif page == "Policy Studio":
        page_policy(policy)
    elif page == "Diagnostics":
        page_diagnostics()
    elif page == "Settings":
        page_settings()
    else:
        st.info("Sayfa yok.")


if __name__ == "__main__":
    main()
