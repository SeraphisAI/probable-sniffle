<# Backward-compat wrapper: katopu_bootstrap_fresh.ps1
   This project standardized on katopu_install.ps1.
#>
param(
  [string]$PackageZip = "",
  [string]$InstallRoot = "C:\katopu_genlab_ultra_final",
  [switch]$RemoveOld,
  [switch]$FreshData,
  [switch]$RequireApiKey,
  [string]$ApiKey = "",
  [switch]$WriteDotEnv
)

& "$PSScriptRoot\katopu_install.ps1" @PSBoundParameters
