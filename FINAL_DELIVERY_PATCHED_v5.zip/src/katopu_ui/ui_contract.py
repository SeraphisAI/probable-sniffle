from __future__ import annotations

# This module contains UI layout strings and CSS that can be unit-tested
# without importing Streamlit.

APP_VERSION = "0.3.0"

GLOBAL_CSS = r"""
<style>
:root{
  --k-bg: #0b1220;
  --k-panel: rgba(255,255,255,0.06);
  --k-panel2: rgba(255,255,255,0.08);
  --k-border: rgba(255,255,255,0.12);
  --k-text: rgba(255,255,255,0.92);
  --k-muted: rgba(255,255,255,0.72);
  --k-good: rgba(61, 199, 102, 0.95);
  --k-warn: rgba(255, 196, 0, 0.95);
  --k-bad: rgba(255, 86, 86, 0.95);
  --k-link: rgba(110, 168, 255, 0.95);
  --k-radius: 16px;
  --k-radius2: 12px;
  --k-shadow: 0 10px 30px rgba(0,0,0,0.25);
  --k-font: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji","Segoe UI Emoji";
  --k-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

/* Streamlit chrome */
header, footer { visibility: hidden; height: 0; }
#MainMenu { visibility: hidden; }

/* Single main scroll + avoid sideways overflow */
html, body { overflow-x: hidden; }
* { box-sizing: border-box; }
p, span, div { hyphens: none; }

/* Sidebar look (fixed nav) */
section[data-testid="stSidebar"]{
  border-right: 1px solid var(--k-border);
}
section[data-testid="stSidebar"] .stRadio label, 
section[data-testid="stSidebar"] .stMarkdown {
  font-family: var(--k-font);
}

/* Main container width */
.block-container{
  padding-top: 0.8rem;
  padding-bottom: 2rem;
  max-width: 1480px;
}

/* Cards */
.k-card{
  background: var(--k-panel);
  border: 1px solid var(--k-border);
  border-radius: var(--k-radius);
  box-shadow: var(--k-shadow);
  padding: 14px 14px;
}
.k-card-tight{
  background: var(--k-panel);
  border: 1px solid var(--k-border);
  border-radius: var(--k-radius2);
  padding: 10px 12px;
}
.k-muted{ color: var(--k-muted); font-size: 0.9rem; }
.k-title{ font-weight: 700; }
.k-nowrap{ white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0; }
.k-mono{ font-family: var(--k-mono); }

/* Sticky top bar */
.k-topbar{
  position: sticky;
  top: 0;
  z-index: 50;
  backdrop-filter: blur(10px);
  margin-bottom: 0.8rem;
}
.k-topbar-inner{
  display: flex; align-items: center; justify-content: space-between;
  gap: 12px;
}
.k-badges{ display:flex; gap:8px; align-items:center; flex-wrap:wrap; justify-content:flex-end;}
.k-badge{
  border:1px solid var(--k-border);
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  line-height: 16px;
  background: var(--k-panel2);
}
.k-badge.good{ border-color: rgba(61,199,102,0.5); }
.k-badge.warn{ border-color: rgba(255,196,0,0.5); }
.k-badge.bad{ border-color: rgba(255,86,86,0.5); }

/* Diff */
.kdiff-inline{ font-family: var(--k-mono); font-size: 12px; line-height: 1.25; white-space: pre-wrap; word-break: break-all; }
.kdiff-ins{ background: rgba(61,199,102,0.24); border-radius: 6px; padding: 0 1px; }
.kdiff-del{ background: rgba(255,86,86,0.22); text-decoration: line-through; border-radius: 6px; padding: 0 1px; }

.kdiff-sbs { overflow-x: auto; }
.kdiff-sbs table.diff{
  width: 100%;
  border-collapse: collapse;
  font-family: var(--k-mono);
  font-size: 12px;
}
.kdiff-sbs td, .kdiff-sbs th { padding: 2px 6px; border: 1px solid var(--k-border); }
.kdiff-sbs .diff_add { background: rgba(61,199,102,0.18); }
.kdiff-sbs .diff_sub { background: rgba(255,86,86,0.16); }
.kdiff-sbs .diff_chg { background: rgba(255,196,0,0.16); }

/* Responsive: inspector collapses below 1200 */
@media (max-width: 1199px){
  .k-desktop-inspector{ display:none !important; }
  .k-mobile-inspector{ display:block !important; }
}
@media (min-width: 1200px){
  .k-desktop-inspector{ display:block !important; }
  .k-mobile-inspector{ display:none !important; }
}

/* Prevent nested scrolls in cards */
.k-card, .k-card-tight { overflow: visible; }

/* Buttons tighter */
button[kind="primary"], button[kind="secondary"]{
  border-radius: 12px !important;
}
</style>
"""

def topbar_html(product: str, env_label: str, active_gene: str, search_placeholder: str = "Ara (gen/rapor)...") -> str:
    # data-testid allow unit tests
    return f"""
<div class="k-topbar" data-testid="katopu-topbar">
  <div class="k-card k-topbar-inner">
    <div style="display:flex; gap:10px; align-items:center; min-width:0;">
      <div class="k-title k-nowrap" title="{product}" data-testid="katopu-product">{product}</div>
      <div class="k-badge" title="Sürüm" data-testid="katopu-version">v{APP_VERSION}</div>
      <div class="k-badge" title="Ortam" data-testid="katopu-env">{env_label}</div>
      <div class="k-badge" title="Aktif gen" data-testid="katopu-active-gene">{active_gene}</div>
    </div>
    <div style="flex:1; min-width:0; padding:0 8px;">
      <div class="k-card-tight" style="display:flex; align-items:center; gap:8px;">
        <span style="opacity:0.8;">🔎</span>
        <span class="k-muted k-nowrap" data-testid="katopu-search-hint">{search_placeholder}</span>
        <span class="k-muted" style="margin-left:auto;">Ctrl/Cmd+K</span>
      </div>
    </div>
    <div class="k-badges" data-testid="katopu-badges">
      <!-- badges injected by Streamlit -->
    </div>
  </div>
</div>
"""
