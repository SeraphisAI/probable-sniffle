from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple


def _runs_path() -> Path:
    return Path(os.environ.get("KATOPU_UI_RUNS_PATH", "/data/ui_runs.jsonl"))


def _backup_dir() -> Path:
    return Path(os.environ.get("KATOPU_WORKER_BACKUP_DIR", "/data/backups"))


def _now_tag() -> str:
    return time.strftime("%Y%m%d-%H%M%S", time.gmtime())


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    out: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            try:
                obj = json.loads(ln)
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
    return out


def _write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> Tuple[int, int]:
    tmp = path.with_suffix(path.suffix + ".tmp")
    written = 0
    skipped = 0
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            try:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
                written += 1
            except Exception:
                skipped += 1
    tmp.replace(path)
    return written, skipped


def healthcheck_task() -> Dict[str, Any]:
    p = _runs_path()
    return {
        "ok": True,
        "runs_path": str(p),
        "exists": p.exists(),
        "size_bytes": p.stat().st_size if p.exists() else 0,
    }


def compact_runs_jsonl(*, keep_deleted: bool = False, keep_archived: bool = True) -> Dict[str, Any]:
    """
    Compacts ui_runs.jsonl by:
      - keeping the latest base run per run_id (last base wins)
      - keeping the latest meta per run_id (last meta wins)
      - emitting one merged record per run_id
    Default is conservative: keep archived, drop deleted unless keep_deleted=True.
    """
    path = _runs_path()
    rows = _read_jsonl(path)

    base_by: Dict[str, Dict[str, Any]] = {}
    meta_by: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        rid = r.get("run_id")
        if not rid:
            continue
        if r.get("_type") == "meta":
            meta_by[rid] = r
        else:
            base_by[rid] = r

    merged: List[Dict[str, Any]] = []
    for rid, base in base_by.items():
        meta = meta_by.get(rid) or {}
        out = dict(base)
        for k in ("pinned", "deleted", "archived", "tags", "label", "note", "report_name"):
            if k in meta:
                out[k] = meta.get(k)
        if (not keep_archived) and bool(out.get("archived")):
            continue
        if (not keep_deleted) and bool(out.get("deleted")):
            continue
        merged.append(out)

    merged.sort(key=lambda x: str(x.get("ts_iso", "")))

    if path.exists():
        bdir = _backup_dir()
        bdir.mkdir(parents=True, exist_ok=True)
        backup = bdir / f"ui_runs.jsonl.backup.{_now_tag()}"
        shutil.copy2(path, backup)

    written, skipped = _write_jsonl_atomic(path, merged)
    return {
        "ok": True,
        "action": "compact_runs_jsonl",
        "input_rows": len(rows),
        "output_rows": len(merged),
        "written": written,
        "skipped": skipped,
        "runs_path": str(path),
    }


def purge_deleted_runs_jsonl() -> Dict[str, Any]:
    return compact_runs_jsonl(keep_deleted=False, keep_archived=True)
