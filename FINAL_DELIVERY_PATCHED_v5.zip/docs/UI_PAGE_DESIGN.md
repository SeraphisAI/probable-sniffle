# UI Page Design — Katopu GenLab Ultra (v0.3.0)

Bu doküman, **UI sayfasının kayma/taşma/wrap problemlerini sıfırlamak** için uygulanan yerleşim sistemini ve kuralları tanımlar.

## 1) Yerleşim Şeması

**A) Üst Bar (sticky)**  
- Ürün adı + sürüm + ortam rozeti
- Aktif gen rozeti
- Global arama ipucu + komut paleti kısayolu (Ctrl/Cmd+K)
- Sağda durum rozetleri (API / Policy / Telemetry)

**B) Sol Nav (fixed)**  
Streamlit Sidebar kullanılır:  
- Workspace (Lab)
- Multi-Gene Editor
- Reports (History)
- Compare
- Policy Studio
- Telemetry
- Diagnostics
- Settings

**C) Ana Workspace**  
- Girdi paneli: DNA/RNA Sequence + Intent + Mode + Engine
- Kontrol paneli butonları: Run / Generate Spec / Apply / Validate / Compare / Export / Save / Clear / Settings / Diagnostics
- Pipeline stepper: Parse → Spec → Apply → Validate → Report
- Sonuç paneli: Before/After + Inline diff + Side-by-side diff

**D) Sağ Inspector (sticky panel)**  
Streamlit’in sağ sidebar’ı olmadığı için Inspector bir **HTML panel** olarak ana alanda render edilir.  
- Aktif gen meta (Len/GC/Warn)
- Seçili run meta (run_id, ts, status, latency, policy)

## 2) Responsive Kurallar (Streamlit sınırları içinde)

- Sol nav zaten fixed.
- Inspector içerik yoğunluğu düşük tutularak küçük ekranlarda bile taşma engellenir.
- Multi‑Gene Editor ekranında 3 kolon (liste/editör/meta) vardır; dar ekranda View Mode ile sadeleşir.

## 3) Kayma/Taşma/Wrapping Kuralları (kritik)

Uygulanan global CSS (`katopu_ui.ui_contract.GLOBAL_CSS`):

- **Tek ana scroll**: `overflow-x: hidden`, nested scroll minimum.
- Türkçe metinlerde hece hece bölünmeyi engellemek için: `hyphens: none`.
- Kritik etiketler:
  - `.k-nowrap`: `white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width:0`
  - Tooltip için `title` attribute kullanılır.
- Kod/sekans alanları:
  - Monospace (`--k-mono`)
  - Inline diff: `white-space: pre-wrap; word-break: break-all` (sekans için güvenli)
- Kart (card) tasarımı:
  - border + radius + shadow
  - padding standartlaştırıldı
- Streamlit chrome gizleme:
  - header/footer ve MainMenu saklandı.

## 4) Erişilebilirlik

- Bilgilendirici tooltips (title)
- Net durum rozetleri (good/warn/bad)
- Klavye kısayolları metin olarak görünür (Streamlit JS sınırlı olduğundan “best-effort”)

## 5) Tasarım Token’ları

- `--k-border`, `--k-panel`, `--k-muted`, `--k-radius`, `--k-shadow`, `--k-font`, `--k-mono`
