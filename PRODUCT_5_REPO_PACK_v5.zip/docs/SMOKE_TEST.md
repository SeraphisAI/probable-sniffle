# SMOKE_TEST — Katopu GenLab Ultra UI (v0.3.0)

## 0) Hazırlık
- Docker: `cd infra && docker compose up -d --build`
- UI: http://localhost:8501
- API: http://localhost:8000/health

## 1) Layout / Responsive (manuel)
- Normal ekran: sidebar + topbar görünür, yatay taşma yok.
- Uzun Türkçe intent metni: etiketler ellipsis + tooltip ile taşmıyor.
- Uzun sekans (100k+): UI donmuyor (chunk view expander ile).

## 2) Workspace Akışı (happy path)
- DNA/RNA Sequence gir.
- Intent gir (örn: "ilk 5 baz sil").
- Run → sonuç:
  - Before/After alanları dolu
  - Inline diff görünür
  - Side-by-side diff görünür
  - “Değişiklik yok” durumu doğru mesajla gösterilir

## 3) Son 20 Rapor
- Run sonrası “Son 20 Rapor” listesinde yeni kayıt görünür.
- “Aç” → seçili run workspace’te meta olarak görünür.
- “Pin” → pinned state güncellenir.

## 4) Multi‑Gene Editor
- Gen ekle, isim değiştir, sekans değiştir, kaydet.
- FASTA import ile 2 gen ekle.
- Export FASTA (seçili + tüm).

## 5) Compare
- İki rapor seç.
- A/B before-after alanları dolu.
- A.after vs B.after diff:
  - inline diff
  - side-by-side diff

## 6) Export
- Workspace’te Export:
  - run.json indir
  - run.xlsx indir
  - run.pdf indir
  - export_bundle.zip indir

## 7) Diagnostics
- Test Connection (/health) çalışır.
- API down ise: engine Auto ile local fallback çalışır; mesaj net.
