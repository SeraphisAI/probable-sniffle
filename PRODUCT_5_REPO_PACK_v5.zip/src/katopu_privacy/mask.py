from __future__ import annotations

from typing import Any, Dict

_SENSITIVE_KEY_SUBSTRINGS = ("seq", "sequence", "dna", "before", "after")


def mask_sequence(seq: str, keep: int = 8) -> str:
    """Mask a potentially sensitive DNA string.

    Keeps first/last `keep` characters and replaces the middle with an ellipsis.
    """
    s = seq or ""
    if len(s) <= keep:
        return s
    return s[:keep] + "…" + s[-keep:]


def mask_dict(payload: Dict[str, Any], keep: int = 8) -> Dict[str, Any]:
    """Best-effort masking for log/telemetry payloads.

    Only masks values for keys that look like they may contain DNA/sequence content.
    Recurses into nested dicts/lists.
    """
    if not isinstance(payload, dict):
        return {}

    out: Dict[str, Any] = {}
    for k, v in payload.items():
        key_l = str(k).lower()
        should_mask = any(s in key_l for s in _SENSITIVE_KEY_SUBSTRINGS)

        if isinstance(v, str) and should_mask:
            out[k] = mask_sequence(v, keep=keep)
        elif isinstance(v, dict):
            out[k] = mask_dict(v, keep=keep)
        elif isinstance(v, list) and should_mask:
            out[k] = [
                mask_sequence(x, keep=keep) if isinstance(x, str) else x for x in v
            ]
        else:
            out[k] = v

    return out
