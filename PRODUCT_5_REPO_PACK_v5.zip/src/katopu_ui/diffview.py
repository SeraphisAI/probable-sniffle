from __future__ import annotations

import html
import difflib
from typing import List, Optional, Tuple

def _escape_pre(s: str) -> str:
    return html.escape(s, quote=False).replace("\t", "    ")

def diff_stats(before: str, after: str) -> Tuple[int, int, int]:
    sm = difflib.SequenceMatcher(a=before or "", b=after or "")
    added = removed = changed = 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "insert":
            added += (j2 - j1)
        elif tag == "delete":
            removed += (i2 - i1)
        elif tag == "replace":
            changed += max(i2 - i1, j2 - j1)
    return added, removed, changed

def inline_diff_html(before: str, after: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Inline diff with coloring.
    Returns (html, reason_if_missing).
    """
    if before is None or after is None:
        return None, "Before/After boş (None) geldi."
    if not isinstance(before, str) or not isinstance(after, str):
        return None, "Before/After string değil."
    # Choose granularity: line-based for large or multi-line.
    if ("\n" in before) or ("\n" in after) or (len(before) + len(after) > 120_000):
        a = before.splitlines(keepends=True)
        b = after.splitlines(keepends=True)
        join = "".join
    else:
        a = list(before)
        b = list(after)
        join = "".join

    try:
        sm = difflib.SequenceMatcher(a=a, b=b)
        parts: List[str] = []
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "equal":
                parts.append(_escape_pre(join(a[i1:i2])))
            elif tag == "insert":
                parts.append(f"<span class='kdiff-ins'>{_escape_pre(join(b[j1:j2]))}</span>")
            elif tag == "delete":
                parts.append(f"<span class='kdiff-del'>{_escape_pre(join(a[i1:i2]))}</span>")
            elif tag == "replace":
                old = _escape_pre(join(a[i1:i2]))
                new = _escape_pre(join(b[j1:j2]))
                parts.append(f"<span class='kdiff-del'>{old}</span><span class='kdiff-ins'>{new}</span>")
        return "<pre class='kdiff-inline'>" + "".join(parts) + "</pre>", None
    except Exception as e:
        return None, f"Diff üretimi hata verdi: {type(e).__name__}: {e}"

def side_by_side_diff_html(before: str, after: str, *, context: bool = True) -> Tuple[Optional[str], Optional[str]]:
    """
    Side-by-side HTML diff table. Returns (html, reason_if_missing).
    """
    if before is None or after is None:
        return None, "Before/After boş (None) geldi."
    if not isinstance(before, str) or not isinstance(after, str):
        return None, "Before/After string değil."
    try:
        hd = difflib.HtmlDiff(wrapcolumn=80)
        a_lines = (before or "").splitlines()
        b_lines = (after or "").splitlines()
        table = hd.make_table(a_lines, b_lines, fromdesc="Before", todesc="After", context=context, numlines=3)
        return "<div class='kdiff-sbs'>" + table + "</div>", None
    except Exception as e:
        return None, f"Side-by-side diff hata verdi: {type(e).__name__}: {e}"
