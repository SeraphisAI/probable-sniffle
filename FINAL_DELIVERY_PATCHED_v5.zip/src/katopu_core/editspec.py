"""Legacy entry-points for building an EditSpec.

This module originally implemented its own EditSpec generation logic. The project
now has a single, canonical implementation in `katopu_core.omega_engine`.

We keep this file as a thin compatibility layer so older imports don't break.
"""

from __future__ import annotations

import warnings
from typing import Any, Dict, Optional

from katopu_core.omega_engine import intent_to_editspec as _intent_to_editspec


def parse_intent_to_editspec(
    intent: str,
    sequence: Optional[str] = None,
    strict_mode: bool = True,
    request_id: Optional[str] = None,
    spec_version: Optional[str] = None,
) -> Dict[str, Any]:
    """Parse natural-language intent into an EditSpec.

    Notes:
    - `sequence` is accepted for backward compatibility but is not embedded in the
      EditSpec (to avoid leaking raw sequences).
    - `request_id`/`spec_version` are ignored; the canonical builder sets spec
      version internally.
    """
    if sequence is not None:
        warnings.warn(
            "parse_intent_to_editspec(sequence=...) is deprecated; the sequence is not used.",
            DeprecationWarning,
            stacklevel=2,
        )
    if request_id is not None:
        warnings.warn(
            "parse_intent_to_editspec(request_id=...) is deprecated; request_id is not used.",
            DeprecationWarning,
            stacklevel=2,
        )
    if spec_version is not None:
        warnings.warn(
            "parse_intent_to_editspec(spec_version=...) is deprecated; spec_version is managed by the contract.",
            DeprecationWarning,
            stacklevel=2,
        )

    return _intent_to_editspec(intent, strict_mode=strict_mode)
